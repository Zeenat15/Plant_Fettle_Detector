document.addEventListener('DOMContentLoaded', function () {
    var video = document.getElementById('camera');
    var captureButton = document.getElementById('captureButton');
    var stream;

    navigator.mediaDevices.getUserMedia({ video: true })
        .then(function (cameraStream) {
            stream = cameraStream;
            video.srcObject = cameraStream;
            video.onloadedmetadata = function (e) {
                video.play();
            };
        })
        .catch(function (err) {
            console.error('Error accessing camera:', err);
        });

    captureButton.addEventListener('click', function () {
        if (stream) {
            var canvas = document.createElement('canvas');
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            var context = canvas.getContext('2d');
            context.drawImage(video, 0, 0, canvas.width, canvas.height);

            // Convert the canvas content to a data URL representing the captured image
            var imageDataUrl = canvas.toDataURL('image/jpeg');

            // Do something with the captured image data (e.g., display it or send it to a server)
            console.log('Captured Image Data:', imageDataUrl);

            // Optionally, stop the camera stream
            stream.getTracks().forEach(track => track.stop());
        }
    });
});
