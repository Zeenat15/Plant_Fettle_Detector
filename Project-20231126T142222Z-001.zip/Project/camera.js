navigator.mediaDevices.getUserMedia({ video: true })
    .then(function (stream) {
        var video = document.getElementById('camera');
        video.srcObject = stream;
        video.onloadedmetadata = function (e) {
            video.play();
        };
    })
    .catch(function (err) {
        console.error('Error accessing camera:', err);
    });


    // captureScript.js

document.addEventListener('DOMContentLoaded', (event) => {
    const video = document.getElementById('camera');
    const captureButton = document.getElementById('captureButton');

    navigator.mediaDevices.getUserMedia({ video: true })
        .then((stream) => {
            video.srcObject = stream;
        })
        .catch((error) => {
            console.error('Error accessing camera:', error);
        });

    captureButton.addEventListener('click', () => {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');

        // Draw the current frame from the video onto the canvas
        context.drawImage(video, 0, 0, canvas.width, canvas.height);

        // Convert the canvas image to data URL
        const imageData = canvas.toDataURL('image/png');

        // Redirect to the next page with the image data as a URL parameter
        window.location.href = `nextPage.html?imageData=${encodeURIComponent(imageData)}`;
    });
});

    