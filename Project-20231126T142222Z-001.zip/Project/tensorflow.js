<script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs"></script>
